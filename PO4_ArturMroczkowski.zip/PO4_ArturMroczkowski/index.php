<?php
  $myRoot = substr($_SERVER['DOCUMENT_ROOT'], 0, strpos($_SERVER['DOCUMENT_ROOT'], 'public_html'));
  $myPage = $_SERVER['PHP_SELF'];
  require  $myRoot . 'mcr76_hidden/script.php';
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>PO4 Library</title>
    <!--  css  -->
    <link rel="stylesheet" type="text/css" href="css/styles.css.php">
    <!--  font awesome  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css">
    <!--  scripting  -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.8.0/angular.js"></script> 
    <script src="scripts/scripts.js.php"></script>  

  </head>

   <body>
      <!----------------------------------- wrapper ---------------------------------------------->
      <div class="wrapper"  ng-app="myApp" ng-controller="myCtrl">
        
        
          <h1>Welcome to FTC Library</h1>

          
          <!--------------------------------- administration -------------------------------------->
          <div class="adminButtons">
            <h2 class="showHide">Administration <i class="fas fa-chevron-down"></i></h2>
            <div class="accordion">
              <button id="createBooksDB">Create DB Table</button>
              <button id="removeBooksDB">Remove DB Table</button>   
              <button id="importData">Import JSON Data File</button>
              <button id="exportData">Export JSON Data File</button>
              <div class="removeTables">
              <p><span class="warning">Warning!!</span> This feature is blocked to prevent unwanted data remove. Please contact us to unlock it</p>
              <button id="removeTableCol">Remove Table Column</button><br>
            </div>
            </div>
          </div>
          <!---------------------------------end of administration -------------------------------------->
          
          <!------------------------ search for book by id, title, author, isbn ---------------------->
          <div class="searchSectionContainer">
            <h2 class="showHide">Search Book <i class="fas fa-chevron-down"></i></h2>

            <div class="accordion">
              
              <div class="searchSection">
                <div class="searchFields">
                  <div class="searchInputs">
                    <label for="ngReadId">Id:</label><br>
                    <input type="text" id="ngReadId" ng-model="ngReadId">
                  </div>
    
                  <div class="searchInputs">
                    <label for="ngReadTitle">Title:</label><br>
                    <input type="text" id="ngReadTitle" ng-model="ngReadTitle">
                  </div>
    
                  <div class="searchInputs">
                    <label for="ngReadAuthor">Author:</label><br>
                    <input type="text" id="ngReadAuthor" ng-model="ngReadAuthor">
                  </div>
    
                  <div class="searchInputs">
                    <label for="ngReadISBN">ISBN:</label><br>
                    <input type="text" id="ngReadISBN" ng-model="ngReadISBN">
                  </div>
                  
                </div>
                <div>
                  <button id="ngReadBook" ng-click="ngReadBook();">Search Book</button>
                </div>
  
                <div class="displaySearch">
                  <table border="1">
                    <tr>
                      <th>Id <span ng-click="sortBy = 'Id'">&#x25B2;</span><span ng-click="sortBy = '-Id'">&#x25BC;</span></th>
                      <th>Title <span ng-click="sortBy = 'Title'">&#x25B2;</span><span ng-click="sortBy = '-Title'">&#x25BC;</span></th>
                      <th>Author <span ng-click="sortBy = 'Author'">&#x25B2;</span><span ng-click="sortBy = '-Author'">&#x25BC;</span></th>
                      <th>Year <span ng-click="sortBy = 'Year'">&#x25B2;</span><span ng-click="sortBy = '-Year'">&#x25BC;</span></th>
                      <th>ISBN <span ng-click="sortBy = 'ISBN'">&#x25B2;</span><span ng-click="sortBy = '-ISBN'">&#x25BC;</span></th>
                      <th>Cathegory <span ng-click="sortBy = 'Cat'">&#x25B2;</span><span ng-click="sortBy = '-Cat'">&#x25BC;</span></th>
                      <th>Package <span ng-click="sortBy = 'Pack'">&#x25B2;</span><span ng-click="sortBy = '-Pack'">&#x25BC;</span></th>
                      <th>updateDate <span ng-click="sortBy = 'updateDate'">&#x25B2;</span><span ng-click="sortBy = '-updateDate'">&#x25BC;</span></th>
                      <th>Ratings</th>
                      <th>Comments</th>
                      <th>Availability</th>
                      <th>Photo</th>
                    </tr>
                    <tr ng-repeat="row in ngReadBookData | orderBy:sortBy">
                      <td>{{row.id}}</td>
                      <td>{{row.Title}}</td>
                      <td>{{row.Author}}</td>
                      <td>{{row.Year}}</td>
                      <td>{{row.ISBN}}</td>
                      <td>{{row.Cat}}</td>
                      <td>{{row.Pack}}</td>
                      <td>{{row.updateDate}}</td>
                      <td>{{row.Ratings}}</td>
                      <td>{{row.Comments}}</td>
                      <td>{{row.Availability}}</td>
                      <td><img alt="Image not available" ng-src="{{row.Photo}}" style="height:100px;width:100px" /></td>
                    </tr>
                  </table>
                </div>
              </div>
            </div> 
          </div>
          <!----------------------- end of search for book bt title, author, isbn -------------------->
          
          <!--------------------------------- delete book -------------------------------------->
          <div>
            <h2 class="showHide">Delete book from an inventory <i class="fas fa-chevron-down"></i></h2>
            <div class="accordion">
              <label for="deleteId">Book by Id:</label><input type="text" id="deleteId">
              <button id="deleteRecord">Delete Book</button>
            </div>    
          </div>
          <!------------------------------ end of delete book ----------------------------------->

          <!---------------------------------- add new book -------------------------------------->
          <div class="newBook">
            <h2 class="showHide">Add new book to the inventory <i class="fas fa-chevron-down"></i></h2>
            <div class="accordion">
              <div class="newBookInputs">
                <label for="createTitle">Title:</label><input type="text" id="createTitle">
                <label for="createAuthor">Author:</label><input type="text" id="createAuthor">
                <label for="createYear">Year:</label><input type="text" id="createYear">
                <label for="createCathegory">Cathegory:</label><input type="text" id="createCathegory">
                <label for="createPackage">Package:</label><input type="text" id="createPackage">
                <label for="createISBN">ISBN:</label><input type="text" id="createISBN">
                <button id="createRecord">Add New Book</button>
              </div>
            </div>      
          </div>
          <!---------------------------- end of add new book ------------------------------------>

          
          <!------------------------------- add image to the book  ---------------------------------->
          <div class="booksImage">
            <h2 class="showHide">Add an image <i class="fas fa-chevron-down"></i></h2>

            <div class="accordion">
              <div class="addAndUpload">
                <div class="uploadImage">
                  <div>
                    <label for="fileUploadPath">Path:</label><input type="text" id="fileUploadPath" value="public_html/mcr76/library/images/" disabled>
                  </div>                
                  <div>
                    <label for="fileUploadName">Name:</label><input type="text" id="fileUploadName" placeholder="photo_name.jpg"> 
                  </div>               
                  <div>
                    <label for="fileUploadFile">File:</label><input type="file" name="fileUploadFile" id="fileUploadFile">
                  </div>
                  <button id="uploadFile">Upload Image</button>
                </div>
  
                <div class="addImage">
                  <div>
                    <label for="addImgId">Add image to book with ID:</label><input type="text" id="addImgId">
                  </div>
                  <div>
                    <label for="createPhoto">Photo url:</label><input type="text" id="createPhoto" placeholder="images/photo_name.jpg">
                  </div>
                  <button id="addPhoto">Add Image</button>
                </div>
              </div>
            </div>                 
          </div>
          <!---------------------------- end of add image to the book ------------------------------->

          <!----------------------------- update books details ------------------------>
          <div class="updateBookcontainer">
            <h2 class="showHide">Update books details <i class="fas fa-chevron-down"></i></h2>

            <div class="accordion">
              <label for="updateSearchId">Id of Book to update:</label><input type="text" id="updateSearchId">              
              <p><span class="warning">Warning!!</span> All fields are required for new values!</p>              
              <div class="updateBook">
                <div>
                  <label for="updateTitle">Title:</label><br><input type="text" id="updateTitle"> 
                </div>             
                <div>
                  <label for="updateAuthor">Author:</label><br><input type="text" id="updateAuthor">
                </div>              
                <div>
                  <label for="updateCathegory">Cathegory:</label><br><input type="text" id="updateCathegory"> 
                </div>             
                <div>
                  <label for="updatePackage">Package:</label><br><input type="text" id="updatePackage"> 
                </div>             
                <div>
                  <label for="updateISBN">ISBN:</label><br><input type="text" id="updateISBN">
                </div>
                <div>
                  <label for="updateAvailability">Availability:</label><br><input type="text" id="updateAvailability">
                </div>
              </div>
              <button id="updateRecord">Update Record</button>
            </div>   
          </div>
          <!------------------------ end of Update books details -------------------------->


 

         <!---------------------- user section, add comment and rating, display users balance ---------------------->
        <div class="usersSection"> 
            <h2 class="showHide">My Book <i class="fas fa-chevron-down"></i></h2>

            <div class="accordion">
              <div>
                <label for="getThisBook">Get the book with ID:</label><br><input type="text" id="getThisBook">
              </div>              

              <div class="listMyBooks">
                <p>Title: <span id="myBookTitle"></span></p>
                <p>Author: <span id="myBookAuthor"></span></p>
                <p>Year: <span id="myBookYear"></span></p>
                <p>ISBN: <span id="myBookISBN"></span></p>
                <p>Book taken on: <span id="myBookDate"></span></p>
              </div>
              <button id="getBook">Get Book</button>

              <div class="loadMyBooks" >
                <table border="1">
                <tr>
                  <th>Title</th>
                  <th>Author</th>
                  <th>Year</th>
                  <th>ISBN</th> 
                  <th>Original ID</th>
                </tr>
                
                <tr ng-repeat="row in ngMyBooks | orderBy:'OriginalID'">  
                  <td>{{row.Title}}</td>
                  <td>{{row.Author}}</td>
                  <td>{{row.Year}}</td>
                  <td>{{row.ISBN}}</td>
                  <td>{{row.OriginalId}}</td>
                  <!--  ng-click="returnBook(row)" -->
                </tr>
                </table>
                <button type="button" id="returnBook1">Return Book</button>
              </div>

              <div class="displayReturnBook">
                <div>
                  <h3>Comment and Rating</h3>
                  <div>
                    <label for="bookToAddComment">Return book with original ID:</label><br><input type="text" id="bookToAddComment">
                  </div>
                  <div>
                    <label for="bookComment">Comment:</label><br><textarea name="bookComment" id="bookComment" class="bookComment"></textarea> 
                  </div> 
                  <div>
                    <label for="rateBook">Rating:</label><br><input type="text" name="rateBook" id="rateBook" placeholder="Rate from 1 to 6">
                  </div>
                  <!--  <button id="addCommentRating">Add Rating and Comment</button> -->
                </div>
                
                <div>
                  <p>Yours balance is: &euro; <span id="balance"></span></p>
                  <button id="returnBook2">Return Book</button>

                </div>
              </div>
            </div>             
        </div>
        <!----------------  end of users section, add comment and rating, display users balance -------------------------->

        
      </div>
      <!-------------------------------- wrapper end ------------------------------------------->

      <!------------------------------------- footer  ------------------------->
      <div class="footer">
          <p>Artur Mroczkowski 2020</p>
      </div>
      <!---------------------------------end of footer  ------------------------->

  </body>
</html>