<?php
  $myRoot = substr($_SERVER['DOCUMENT_ROOT'], 0, strpos($_SERVER['DOCUMENT_ROOT'], 'public_html'));
  $myPage = $_SERVER['PHP_SELF'];
  require  $myRoot . 'mcr76_hidden/script.php';
  header('Content-Type: application/javascript');
?>
console.log('JavaScript File Rev 0.4');

/* purpose values for data rows: C = create, R = read, U = update, D = delete (CRUD)
   other purpose values: CT = create database table, RT = remove database table
                         AC = add col to table, RC = remove col from table, 
                         ID = import data, ED = export data
*/

var clientTimeZone = Intl.DateTimeFormat().resolvedOptions().timeZone;
var apiKey = 'yv3tq3y0';


//************************************ jQuery ************************************************
//********************************************************************************************
$(document).ready(function(){

    //accordion 
      $('.showHide').click (function(){
        //console.log('heading h2 has been clicked');
        $(this).each(function(){
          $(this).children().toggleClass('fa-chevron-down fa-chevron-up');
          $(this).next().slideToggle();
        });
      });

    // display section with book to return
      $('#returnBook1').click(function(){
        //console.log('returnBook1 has been clicked');
        $('.displayReturnBook').css('display', 'block');
      });
 
    //button to create database table for books on our server
      $('#createBooksDB').click(function() {
        console.log('createDbTable has been clicked!');
        dataString = JSON.stringify(createBooksDB);
        $.post("db.php", {"data": dataString},
        function(data,status){
        //console.log(data + "\nStatus: " + status);
        //console.log(JSON.parse(data), "\nStatus: " + status);
        });
        dataString2 = JSON.stringify(createMyBooksDB);
        $.post("db.php", {"data": dataString2},
        function(data,status){
        //console.log(data + "\nStatus: " + status);
        console.log(JSON.parse(data), "\nStatus: " + status);
        });
      });
    
    // button to remove database table for books on our server 
      $('#removeBooksDB').click(function() {
        console.log('removeBooksDB has been clicked!');
        dataString = JSON.stringify(removeBooksDB);
        $.post("db.php", {"data": dataString},
        function(data,status){
        //console.log(data + "\nStatus: " + status);
        //console.log(JSON.parse(data), "\nStatus: " + status);
        });
        dataString2 = JSON.stringify(removeMyBooksDB);
        $.post("db.php", {"data": dataString2},
        function(data,status){
        //console.log(data + "\nStatus: " + status);
        console.log(JSON.parse(data), "\nStatus: " + status);
        });
      });

    // button to fill out our database with data from our file books.json
      $('#importData').click(function() {
        console.log('importData has been clicked!');
        dataString = JSON.stringify(dataImport);
        $.post("db.php", {"data": dataString},
        function(data,status){
        console.log(data + "\nStatus: " + status);
        });
        dataString2 = JSON.stringify(dataImportMyBooks);
        $.post("db.php", {"data": dataString2},
        function(data,status){
        console.log(data + "\nStatus: " + status);
        });
      });

     // button to save changes to our database       
      $('#exportData').click(function() {
        console.log('exportData has been clicked!');
        dataString = JSON.stringify(dataExport);
          $.post("db.php", {"data": dataString},
          function(data,status){
          //console.log(data + "\nStatus: " + status);
          });
        dataString2 = JSON.stringify(dataExportMyBooks);
          $.post("db.php", {"data": dataString2},
          function(data,status){
          console.log(data + "\nStatus: " + status);
          });
        });


    // button to remove book from inventory
      $('#deleteRecord').click(function() {
        console.log('deleteRecord has been clicked!');
        dataString = JSON.stringify(deleteRecord());
        $.post("db.php", {"data": dataString},
        function(data,status){
          //console.log(data);
          console.log(JSON.parse(data), "\nStatus: " + status);
          });
        });

    // button to add new book
      $('#createRecord').click(function() {
        console.log('createRecord has been clicked!');
        dataString = JSON.stringify(createRecord());
        $.post("db.php", {"data": dataString},
        function(data,status){
          //console.log(data);
          console.log(JSON.parse(data), "\nStatus: " + status);
        });
        });   

    // remove table columns
      $('#removeTableCol').click(function() {
        console.log('removeTableCol has been clicked!');
        dataString = JSON.stringify(dataRemCol);
        $.post("db.php", {"data": dataString},
        function(data,status){
          console.log(data + "\nStatus: " + status);
        });
      });

    //upload image to the server
      $('#uploadFile').click(function() {
        console.log('uploadFile has been clicked!');
        dataString = JSON.stringify(uploadFile());
        formData = new FormData();
        formData.append('data', dataString);
        fileFormField = $('#fileUploadFile')[0];
        //console.log(fileFormField);
        formData.append('file', fileFormField.files[0], $('#fileUploadName'));
        $.ajax({
          url: "db.php",
          type: 'POST',
          data: formData,
          cache: false,
          contentType: false,
          processData: false,    
          success: function (data, status) {
            //console.log(data);
            console.log(JSON.parse(data), "\nStatus: " + status);
          }
        });
      });

    //button to add image to the book
      $('#addPhoto').click(function(){
        console.log('addPhoto has been clicked!');
        dataString = JSON.stringify(addPhoto());
        $.post("db.php", {"data": dataString},
        function(data,status){
          console.log(data);
          console.log(JSON.parse(data), "\nStatus: " + status);
        });
      });

    //button to update book details
      $('#updateRecord').click(function() {
        console.log('updateRecord has been clicked!');
        dataString = JSON.stringify(updateRecord());
        $.post("db.php", {"data": dataString},
        function(data,status){
          //console.log(data);
          console.log(JSON.parse(data), "\nStatus: " + status);
        });
      });

    // button to get book
      $('#getBook').click(function(){
        console.log('getBook has been clicked!');
        //get details of the book user want to take home
        dataString = JSON.stringify(getBook());
        //console.log('dataString: ', dataString);
        $.post("db.php", {"data": dataString},
          function(data,status){
          //console.log(data);
          console.log(JSON.parse(data), "\nStatus: " + status);
          purchaseBook = JSON.parse(data);
          // if statement here - if book is available or not
          //console.log('original id is', purchaseBook.data.inventory[0].id);
          purchaseBookAvailable = purchaseBook.data.inventory[0].Availability;
          if (purchaseBookAvailable == 1){
            purchaseBookId = purchaseBook.data.inventory[0].id;
            purchaseBookTitle = purchaseBook.data.inventory[0].Title;
            $('#myBookTitle').html(purchaseBookTitle);
            purchaseBookAuthor = purchaseBook.data.inventory[0].Author;
            $('#myBookAuthor').html(purchaseBookAuthor);
            purchaseBookYear = purchaseBook.data.inventory[0].Year;
            $('#myBookYear').html(purchaseBookYear);
            purchaseBookISBN = purchaseBook.data.inventory[0].ISBN;
            $('#myBookISBN').html(purchaseBookISBN);
            myDate = new Date();
            day = myDate.getDate();
            month = myDate.getMonth() + 1;
            year = myDate.getFullYear();
            hour = myDate.getHours();
            minutes = myDate.getMinutes();
            purchaseDateUnix = myDate.getTime();
            //console.log(purchaseDateUnix);
            purchaseDateToDisplay = [day + '-' + month +'-' + year + ', at:' + hour + ':' + minutes];
            //console.log('Books purchase date is', purchaseDateToDisplay);
            $('#myBookDate').html(purchaseDateToDisplay);
            //  date to save it to server cant be to big number so we need to
            //  display it in lower number - we will display it in days since 1970
            //  by deviding unix time by 86400000
            purchaseDate = myDate.getTime() / 86400000;
            //get this book details and pass it to mybooks.json
            dataString3 = JSON.stringify(addBookToMyBooks());
            $.post("db.php", {"data": dataString3},
              function(data,status){
                //console.log(data);
                console.log(JSON.parse(data), "\nStatus: " + status);
              });

              // function to add new book to "my" books file
                function addBookToMyBooks() {
                  return {"mybooks": {"apiKey": apiKey,
                            "timeZone": clientTimeZone,
                            "purpose": "C",
                            "debug": true,
                            "sort": "Title ASC",
                            "startVal": -1,
                            "pageSize": -1,
                            "data": [
                                    {"colName": "Title",
                                      "new": purchaseBookTitle,
                                      "strict": false,
                                      "dataType": "String"},
                                    {"colName": "Author",
                                      "new": purchaseBookAuthor,
                                      "strict": false,
                                      "dataType": "String"},
                                    {"colName": "Year",
                                      "new": purchaseBookYear,
                                      "strict": false,
                                      "dataType": "Number"},
                                      {"colName": "ISBN",
                                      "new": purchaseBookISBN,
                                      "strict": false,
                                      "dataType": "String"},
                                      {"colName": "Purchase",
                                      "new": purchaseDate,
                                      "strict": false,
                                      "dataType": "Number"},
                                      {"colName": "OriginalId",
                                      "new": purchaseBookId,
                                      "strict": false,
                                      "dataType": "Number"}
                                    ]
                          }};
                }

          } 
          else if(purchaseBookAvailable == 0 || purchaseBookAvailable == null){
            alert('Sorry this book is not available. Try different book');
          }
        }); 
        
        dataString2 = JSON.stringify(getBookDetails());
        $.post("db.php", {"data": dataString2},
        function(data,status){
          //console.log(data);
          //console.log('Data with upgrated Availability status has returned');
          console.log(JSON.parse(data), "\nStatus: " + status);
        });

        
      });

    //button to return book
      $('#returnBook2').click(function(){
         console.log('returnBook has been clicked!');
         //first we need to read when book was taken
         dataString = JSON.stringify(readBookDetails());
         $.post("db.php", {"data": dataString},
         function(data,status){
          //console.log(data);
          console.log(JSON.parse(data), "\nStatus: " + status);
          returnBook = JSON.parse(data);
          //console.log('details of book when clicked return book', returnBook);
          currentDate = new Date().getTime() / 86400000;  // todays day since 1970
          //console.log('Current date is ', currentDate);
          //   purchaseBookISBN = purchaseBook.data.mybooks[0].ISBN;
          retrurBookPurchase = returnBook.data.mybooks[0].Purchase;
          //console.log('purchase date of returned book is ', retrurBookPurchase);
          //
          //  to test if this script works after clicking get book button on the page need go to cpanel
          //  in cpanel we need to edit Purchase column if we want to see if balance statement works
          //   need to change Purchase value to "18470"  for 27.07.2020 or "18453" for 19,07,2020
          //
          //  1 day in miliseconds    (1000ms * 60sec * 60 min * 24hpurs = 86400000ms)
          difference = currentDate - retrurBookPurchase;
          //console.log('days since purchase of book is:', difference);
          timeGone = Math.floor(difference);
          //console.log(timeGone);
          if (timeGone < 7){
            chargeAmount = 0;
            $('#balance').html(chargeAmount);
          }
          else if (timeGone > 7 && timeGone < 14){
            chargeAmount = 0.50;
            alert('You have the book for too long. A charge is applied');
            $('#balance').html(chargeAmount);
          }
            else if(timeGone > 14 && timeGone < 21){
            chargeAmount = 1;
            alert('You have the book for too long. A charge is applied');
            $('#balance').html(chargeAmount);
          }else if(timeGone > 21){
            chargeAmount = 50;
            alert('Book has been keept for to long. Fine of euro 50 has been charged');
            $('#balance').html(chargeAmount);
          }
        });

        //comment and rating
        dataString2 = JSON.stringify(addCommentRating());
        $.post("db.php", {"data": dataString2},
        function(data,status){
          //console.log(data);
          console.log(JSON.parse(data), "\nStatus: " + status);
        });
      
        function addCommentRating(){
          return{"inventory": {"apiKey": apiKey,
          "timeZone": clientTimeZone,
          "purpose": "U",
          "debug": true,
          "sort": "n/a",
          "startVal": -1,
          "pageSize": -1,
          "data": [{"colName": "id",
                  "search": $('#bookToAddComment').val(),
                  "strict": true,
                  "useForSearch": true,
                  "new": -1,
                  "update": false,
                  "dataType": "Number"},
                  {"colName": "Comments",
                  "search": "",
                  "strict": false,
                  "useForSearch": false,
                  "new": $('#bookComment').val(),
                  "update": true,
                  "dataType": "String"},
                  {"colName": "Ratings",
                  "search": "",
                  "strict": false,
                  "useForSearch": false,
                  "new": $('#rateBook').val(),
                  "update": true,
                  "dataType": "String"}
                  ]
        }};
      }

        //this part is to set  availability back to 1
        dataString3 = JSON.stringify(resetAvailability());
        $.post("db.php", {"data": dataString3},
        function(data,status){
          //console.log(data);
          console.log(JSON.parse(data), "\nStatus: " + status);
        });

        //this part is to remove book from "my" books
        dataString4 = JSON.stringify(removeFromMyBooks());
        $.post("db.php", {"data": dataString4},
        function(data,status){
          //console.log(data);
          console.log(JSON.parse(data), "\nStatus: " + status);
          });
        
          location.reload();
    });

    
});


// create variable for database with books
    var createBooksDB = {"inventory": {"apiKey": apiKey,
    "timeZone": clientTimeZone,
    "purpose": "CT",
    "debug": true,
    "sort": "n/a",
    "startVal": -1,
    "pageSize": -1,
    "data": [{"colName":"Title",
            "unique": false,
            "dataType":"String",
            "dataLength": 250},
            {"colName":"Author",
            "unique": false,
            "dataType":"String",
            "dataLength": 250},
            {"colName":"Year",
            "unique": false,
            "dataType":"Number",
            "dataLength": 0},
            {"colName":"ISBN",
            "unique": false,
            "dataType":"String",
            "dataLength": 25},
            {"colName":"Cat",
            "unique": false,
            "dataType":"String",
            "dataLength": 50},
            {"colName":"Pack",
            "unique": false,
            "dataType":"String",
            "dataLength": 50},
            {"colName":"Ratings",
            "unique": false,
            "dataType":"String",
            "dataLength": 50},
            {"colName":"Comments",
            "unique": false,
            "dataType":"String",
            "dataLength": 50},
            {"colName":"Availability",
            "unique": false,
            "dataType":"String",
            "dataLength": 50},
            {"colName":"Photo",
            "unique": false,
            "dataType":"String",
            "dataLength": 255},
            {"colName":"Purchase",
            "unique": false,
            "dataType":"Number",
            "dataLength": 0}
            ]
    }};

// create variable for database with "my" books books
    var createMyBooksDB = {"mybooks": {"apiKey": apiKey,
    "timeZone": clientTimeZone,
    "purpose": "CT",
    "debug": true,
    "sort": "n/a",
    "startVal": -1,
    "pageSize": -1,
    "data": [{"colName":"Title",
            "unique": false,
            "dataType":"String",
            "dataLength": 250},
            {"colName":"Author",
            "unique": false,
            "dataType":"String",
            "dataLength": 250},
            {"colName":"Year",
            "unique": false,
            "dataType":"Number",
            "dataLength": 0},
            {"colName":"ISBN",
            "unique": false,
            "dataType":"String",
            "dataLength": 25},
            {"colName":"Purchase",
            "unique": false,
            "dataType":"Number",
            "dataLength": 0},
            {"colName":"OriginalId",
            "unique": true,
            "dataType":"Number",
            "dataLength": 0}
            ]
    }};

// variable for database to remove db with books
    var removeBooksDB = {"inventory": {"apiKey": apiKey,
        "timeZone": clientTimeZone,
        "purpose": "RT",
        "debug": true,
        "sort": "n/a",
        "startVal": -1,
        "pageSize": -1,
        "data": [
                ]
    }};
    
// variable for database to remove db with "my" books
    var removeMyBooksDB = {"mybooks": {"apiKey": apiKey,
    "timeZone": clientTimeZone,
    "purpose": "RT",
    "debug": true,
    "sort": "n/a",
    "startVal": -1,
    "pageSize": -1,
    "data": [
            ]
    }};

// variable for button to import data
    var dataImport = {"inventory": {"apiKey": apiKey,
    "timeZone": clientTimeZone,
    "purpose": "ID",
    "debug": true,
    "sort": "n/a",
    "startVal": -1,
    "pageSize": -1,
    "data": [{"format": "JSON"}
            ]
    }};

// variable for button to import data for "my" books
    var dataImportMyBooks = {"mybooks": {"apiKey": apiKey,
    "timeZone": clientTimeZone,
    "purpose": "ID",
    "debug": true,
    "sort": "n/a",
    "startVal": -1,
    "pageSize": -1,
    "data": [{"format": "JSON"}
            ]
    }};

// variable for button to export data
    var dataExport = {"inventory": {"apiKey": apiKey,
    "timeZone": clientTimeZone,
    "purpose": "ED",
    "debug": true,
    "sort": "n/a",
    "startVal": -1,
    "pageSize": -1,
    "data": [{"format": "JSON"}
            ]
    }};

// variable for button to export data for "my" books
    var dataExportMyBooks = {"mybooks": {"apiKey": apiKey,
    "timeZone": clientTimeZone,
    "purpose": "ED",
    "debug": true,
    "sort": "n/a",
    "startVal": -1,
    "pageSize": -1,
    "data": [{"format": "JSON"}
            ]
    }};

// create variable to remove columns
    var dataRemCol = {"inventory": {"apiKey": apiKey,
    "timeZone": clientTimeZone,
    "purpose": "RC",
    "debug": true,
    "sort": "n/a",
    "startVal": -1,
    "pageSize": -1,
    "data": [
            // to remove table from code 
            // {"colName":"Rating"},
            // {"colName":"Comments"}
            ]
    }};


// function to delete book from inventory
  function deleteRecord() {
      return {"inventory": {"apiKey": apiKey,
                "timeZone": clientTimeZone,
                "purpose": "D",
                "debug": true,
                "sort": "n/a",
                "startVal": -1,
                "pageSize": -1,
                "data": [{"colName": "id",
                          "search": $('#deleteId').val(),
                          "strict": true,
                          "dataType": "Number"}
                        ]
              }};
    }

// function to add new book to the inventory
  function createRecord() {
      return {"inventory": {"apiKey": apiKey,
                "timeZone": clientTimeZone,
                "purpose": "C",
                "debug": true,
                "sort": "Title ASC",
                "startVal": -1,
                "pageSize": -1,
                "data": [{"colName": "Title",
                          "new": $('#createTitle').val(),
                          "strict": false,
                          "dataType": "String"},
                        {"colName": "Author",
                          "new": $('#createAuthor').val(),
                          "strict": false,
                          "dataType": "String"},
                        {"colName": "Year",
                          "new": $('#createYear').val(),
                          "strict": false,
                          "dataType": "Number"},
                        {"colName": "Cat",
                          "new": $('#createCathegory').val(),
                          "strict": false,
                          "dataType": "String"},
                          {"colName": "Pack",
                          "new": $('#createPackage').val(),
                          "strict": false,
                          "dataType": "String"},
                          {"colName": "ISBN",
                          "new": $('#createISBN').val(),
                          "strict": false,
                          "dataType": "String"},
                        // {"colName": "Ratings",
                        // "new": $('#createRating').val(),
                        // "strict": false,
                        //  "dataType": "Number"},
                        // {"colName": "Comments",
                        // "new": $('#createComments').val(),
                        // "strict": false,
                        // "dataType": "String"},
                          {"colName": "Availability",
                          "new": $('#createAvailability').val(),
                          "strict": false,
                          "dataType": "String"}
                        ]
              }};
    }


//function to upload image to the existing book
  function uploadFile() {
    return {"_file_": {"apiKey": apiKey,
              "timeZone": clientTimeZone,
              "purpose": "FU",
              "debug": true,
              "path": $('#fileUploadPath').val(),
              "name": $('#fileUploadName').val(),
              "sort": "n/a",
              "startVal": -1,
              "pageSize": -1
              }};

    }

//function to add image to the book
  function addPhoto(){
    return{"inventory": {"apiKey": apiKey,
              "timeZone": clientTimeZone,
              "purpose": "U",
              "debug": true,
              "sort": "n/a",
              "startVal": -1,
              "pageSize": -1,
              "data": [{"colName": "id",
                      "search": $('#addImgId').val(),
                      "strict": true,
                      "useForSearch": true,
                      "new": -1,
                      "update": false,
                      "dataType": "Number"},
                      {"colName": "Photo",
                      "search": "",
                      "strict": false,
                      "useForSearch": false,
                      "new": $('#createPhoto').val(),
                      "update": true,
                      "dataType": "String"}
                      ]
            }};
    }

//function to upgrade books details
  function updateRecord() {
    return {"inventory": {"apiKey": apiKey,
              "timeZone": clientTimeZone,
              "purpose": "U",
              "debug": true,
              "sort": "n/a",
              "startVal": -1,
              "pageSize": -1,
              "data": [{"colName": "id",
                        "search": $('#updateSearchId').val(),
                        "strict": true,
                        "useForSearch": true,
                        "new": -1,
                        "update": false,
                        "dataType": "Number"},
                      {"colName": "Title",
                        "search": "",
                        "strict": false,
                        "useForSearch": false,
                        "new": $('#updateTitle').val(),
                        "update": true,
                        "dataType": "String"},
                      {"colName": "Author",
                        "search": "",
                        "strict": false,
                        "useForSearch": false,
                        "new": $('#updateAuthor').val(),
                        "update": true,
                        "dataType": "String"},
                      {"colName": "Cat",
                        "search": "",
                        "strict": false,
                        "useForSearch": false,
                        "new": $('#updateCathegory').val(),
                        "update": true,
                        "dataType": "String"},
                      {"colName": "Pack",
                        "search": "",
                        "strict": false,
                        "useForSearch": false,
                        "new": $('#updatePackage').val(),
                        "update": true,
                        "dataType": "String"},
                        {"colName": "ISBN",
                        "search": "",
                        "strict": false,
                        "useForSearch": false,
                        "new": $('#updateISBN').val(),
                        "update": true,
                        "dataType": "String"},
                        {"colName": "Availability",
                        "search": "",
                        "strict": false,
                        "useForSearch": false,
                        "new": $('#updateAvailability').val(),
                        "update": true,
                        "dataType": "String"}
                      ]
            }};
    }

// function to get time of purchase(get) of book
  function getBook() {
    return {"inventory": {"apiKey": apiKey,
              "timeZone": clientTimeZone,
              "purpose": "R",
              "debug": true,
              "sort": "n/a",
              "startVal": -1,
              "pageSize": -1,
              "data": [{"colName": "Id",
                        "search": $('#getThisBook').val(),
                        "strict": false,
                        "dataType": "Number"}
                      ]
            }};
    }

//function to change avaialbility and date of purchase book
  function getBookDetails() {
    var getTime = new Date().getTime() /86400000;    //this result will show how many days passed since 1970
    console.log(getTime);   
    return {"inventory": {"apiKey": apiKey,
              "timeZone": clientTimeZone,
              "purpose": "U",
              "debug": true,
              "sort": "n/a",
              "startVal": -1,
              "pageSize": -1,
              "data": [{"colName": "id",
                        "search": $('#getThisBook').val(),
                        "strict": true,
                        "useForSearch": true,
                        "new": -1,
                        "update": false,
                        "dataType": "Number"},
                      {"colName": "Availability",
                        "search": "",
                        "strict": false,
                        "useForSearch": false,
                        "new": "0",
                        "update": true,
                        "dataType": "String"},
                      {"colName": "Purchase",
                        "search": "",
                        "strict": false,
                        "useForSearch": false,
                        "new": getTime,
                        "update": true,
                        "dataType": "Number"}
                      ]
            }};
    }

// function to on return chanage availability back to 1 and help count time
  function readBookDetails() {
    return {"mybooks": {"apiKey": apiKey,
              "timeZone": clientTimeZone,
              "purpose": "R",
              "debug": true,
              "sort": "n/a",
              "startVal": -1,
              "pageSize": -1,
              "data": [{"colName": "OriginalId",
                        "search": $('#bookToAddComment').val(),
                        "strict": false,
                        "dataType": "Number"}
                      ]
            }};
  }

// function to sent new values for Availability
  function resetAvailability(){
    return{"inventory": {"apiKey": apiKey,
              "timeZone": clientTimeZone,
              "purpose": "U",
              "debug": true,
              "sort": "n/a",
              "startVal": -1,
              "pageSize": -1,
              "data": [{"colName": "id",
                      "search": $('#bookToAddComment').val(),
                      "strict": true,
                      "useForSearch": true,
                      "new": -1,
                      "update": false,
                      "dataType": "Number"},
                      {"colName": "Availability",
                      "search": "",
                      "strict": false,
                      "useForSearch": false,
                      "new": "1",
                      "update": true,
                      "dataType": "String"}
                      ]
            }};
    }

//
  function removeFromMyBooks() {
    return {"mybooks": {"apiKey": apiKey,
              "timeZone": clientTimeZone,
              "purpose": "D",
              "debug": true,
              "sort": "n/a",
              "startVal": -1,
              "pageSize": -1,
              "data": [{"colName": "OriginalId",
                        "search": $('#bookToAddComment').val(),
                        "strict": true,
                        "dataType": "Number"}
                      ]
            }};
  }


// **************************************  AngularJS  ********************************************* 
//*************************************************************************************************  
var app = angular.module('myApp', []);
app.controller('myCtrl', function($scope, $http, $log) {
      
    // display my books
      var data = [];
      var jsObj = {"mybooks": {"apiKey": 'yv3tq3y0',
                                "timeZone": clientTimeZone,
                                "purpose": "R",
                                "debug": true,
                                "sort": "n/a",
                                "startVal": -1,
                                "pageSize": -1,
                                "data": []
                              }};
        $log.info(jsObj);
        var formData ='data=' + JSON.stringify(jsObj); 
        $http({
          url: 'db.php',
          method: "POST",
          data: formData,
          headers: {'Content-Type': 'application/x-www-form-urlencoded'}
        }).then(function (response) {
          $log.info('Users books are posted succesfully');
          //$log.info(response);
          //$log.info(response['data']);
          $log.info(response.data, "\nStatus: " + response.status);
          //$log.info('here we are');
          $scope.ngMyBooks = response.data.data.mybooks;
          }, function (response) {
            $log.info('status:', response.status);
          });
        

       
    
    // search by id, title, author, ISBN
      $scope.ngReadBook= function() {
        var data = [];
        if ($scope.ngReadId) {
          $log.info('Id is a search parameter');
          data.push({"colName": "id",
                          "search": $scope.ngReadId,
                          "strict": false,
                          "dataType": "Number"});
        }
        if ($scope.ngReadTitle) {
          $log.info('Title is a search parameter');
          data.push({"colName": "Title",
                          "search": $scope.ngReadTitle,
                          "strict": false,
                          "dataType": "String"});
        }
        if ($scope.ngReadAuthor) {
          $log.info('Author is a search parameter');
          data.push({"colName": "Author",
                          "search": $scope.ngReadAuthor,
                          "strict": false,
                          "dataType": "String"});
        }
        if ($scope.ngReadISBN) {
          $log.info('ISBN is a search parameter');
          data.push({"colName": "ISBN",
                          "search": $scope.ngReadISBN,
                          "strict": false,
                          "dataType": "String"});
        }
        $log.info(data);
        var jsObj = {"inventory": {"apiKey": apiKey,
                                "timeZone": clientTimeZone,
                                "purpose": "R",
                                "debug": true,
                                "sort": "n/a",
                                "startVal": -1,
                                "pageSize": -1,
                                "data": data}}
        $log.info(jsObj);
        var formData = 'data=' + JSON.stringify(jsObj);
        $http({
          url: 'db.php',
          method: "POST",
          data: formData,
          headers: {'Content-Type': 'application/x-www-form-urlencoded'}
        }).then(function (response) {
            $log.info('Post Data Submitted Successfully!');
            //$log.info(response);
            //$log.info(response['data']);
            $log.info(response.data, "\nStatus: " + response.status);
            $scope.ngReadBookData = response.data.data.inventory;
            //reseting all inputs after every search
            $scope.ngReadId = "";
            $scope.ngReadTitle = "";
            $scope.ngReadAuthor = "";
            $scope.ngReadISBN = "";

            //sorting results
            $scope.sortBy = 'Title';
        }, function (response) {
            $log.info('status:', response.status);
        });
      };
    
      
      
      


      


});