<?php
  $myRoot = substr($_SERVER['DOCUMENT_ROOT'], 0, strpos($_SERVER['DOCUMENT_ROOT'], 'public_html'));
  $myPage = $_SERVER['PHP_SELF'];
  require  $myRoot . 'mcr76_hidden/script.php';
  header('Content-Type: text/css');
?>
/* CSS File Rev 0.1 */




body {
    background-color: lightblue;
    font-family: sans-serif;
    font-size: 16px;
    position: relative;
    padding-bottom: 40px;
    margin: 0;
}

h1{
    text-align: center;
}

h2 i{
    background-color: white;
    border-radius: 50%;
    padding: 2px 4px;
    cursor: pointer;
}

input, textarea{
    padding: 5px;
    font-size: 16px;
    margin: 5px 0;
    max-width: 90%;
}

  
button{
    padding:5px;
    font-size: 16px;  
    background-color: rgb(238, 210, 176);  
    margin: 5px 0;  
    cursor: pointer;
}

button:hover{
    background-color: rgb(223, 166, 91);
}
  
.wrapper{
    background-color: rgba(89, 180, 93, 0.3);
    padding: 15px;
    margin: 20px auto 30px auto;
    width:80%;
}
  
.wrapper > div{
    border: 1px solid black;
    margin-bottom: 10px;
    padding: 10px;
  }
  
.accordion{
    display: none;
}

.warning{
    color: red;
}

/* search for book section  */

.searchSection{
    width: 100%;
}

.searchFields{
    display: flex;
    flex-wrap:wrap;
}

.searchInputs{
    padding: 10px;
    box-sizing: border-box;
    width:300px;
}

.searchInputs input{
    width: 100%;
    margin: 5px 0;
    box-sizing: border-box;
}

.displaySearch{ 
    max-height: 60vh;
    box-sizing: border-box;
    overflow: auto;
}

/* add new book to the inventory*/

.newBookInputs{
    display:flex;
    flex-direction: column;
}

.newBookInputs input{
    width:500px;
    margin:5px 0;
}

.newBookInputs button{
    align-self: flex-start
}

/* add and upload image*/

.addAndUpload{
    display: flex;
    flex-direction: row;
    flex-wrap: wrap;
    justify-content: space-evenly;
}

.uploadImage, .addImage{
    padding: 10px;
    border: 1px solid grey;
    margin-bottom: 10px;
    max-width: 95%;
}

/* update book details */

.updateBook input{
    width: 500px;
    max-width: 90%;
}

/* my book*/

.bookComment{
    width:500px;
    height:150px;
}

.displayReturnBook{
    display: none;
}

/* footer*/

.footer{
    position: absolute;
    bottom: 0;
    width: 100%;
}

.footer p{
    text-align: center;
    
}



